function fibo(num) {
    let numeros = []
    let a,b,c = 0
    
    for (let index = 0; index < num; index++) {
        if (index == 0) {
            b = 0    
            c = 1    
        }
        else  {
            a = numeros[index-1]
            c = a + b
            b = numeros[index-1]
        }
        numeros = [...numeros, c]
        
        console.log(c)
    }
    return numeros
    
}

const fibonaci = fibo(6)

console.log(fibonaci)
